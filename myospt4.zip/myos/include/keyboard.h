
#include <stdint.h>


uint8_t scan(void);